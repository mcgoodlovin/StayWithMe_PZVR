STAY WITH ME - VR CHAT & VOICE (BUILD 42)
Author: mcgoodlovin
============================================================
Required Workshop Mods:
  - ZombieBuddy       (3619862853 / ID: ZombieBuddy)
  - Project Viewpoint (3809306528 / ID: Viewpoint)
  - PZVR              (3816830877 / ID: PZVR)
  - Stay With Me      (3800989007 / ID: Bridge)

1. Copy "StayWithMe_PZVR" into your Zomboid/mods/ folder and enable it after Stay With Me.
2. START VOICE AUDIO BEFORE LAUNCHING VR:
   - Kokoro-82M Neural (Recommended): Double-click "Start_Voice_Reader.bat" (or run: python3 ./bridge/swm_tts_kokoro.py)
   - Piper Neural TTS (~60 MB/voice): Double-click "Start_Voice_Reader.bat" (or run: python3 ./bridge/swm_tts_piper.py)
   - Windows Built-in + OneCore     : Double-click "Start_Voice_Reader.bat"
   - eSpeak NG                      : ./bridge/swm_tts_espeak.sh
3. IN-GAME VR & OPTIONS:
   - Open your PZVR offhand palm radial menu and select the speech-bubble icon
     ("Show Companion Chat" / "Hide Companion Chat") or press F9.
   - Look at your left palm to read companion dialogue cleanly without overlapping your wrist watch.
   - The palm panel automatically hides whenever Viewpoint's inventory or pause screen is open.
   - Open Options -> Mods -> "Stay With Me - VR Chat & Voice" to switch TTS voices or set the
     "Companion Name Failsafe" (when filled in, TTS ONLY speaks lines formatted as "<Name>: ...").
