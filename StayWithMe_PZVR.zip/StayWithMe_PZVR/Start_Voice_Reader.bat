@echo off
title Stay With Me VR - Windows Voice Reader - by mcgoodlovin
powershell -NoExit -ExecutionPolicy Bypass -File "%~dp0bridge\swm_tts_daemon.ps1"
