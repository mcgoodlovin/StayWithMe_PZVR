--[[
  Stay With Me - VR Chat & Voice Bridge (Build 42)
  Author: mcgoodlovin
  Requires:
    - ZombieBuddy       (3619862853 / ID: ZombieBuddy)
    - Project Viewpoint (3809306528 / ID: Viewpoint)
    - PZVR              (3816830877 / ID: PZVR)
    - Stay With Me      (3800989007 / ID: Bridge)
]]

require "ISUI/ISPanel"
require "ISUI/ISRadialMenu"

StayWithMe_VR = StayWithMe_VR or {}
StayWithMe_VR.Author = "mcgoodlovin"
StayWithMe_VR.QueueFile = "staywithme_vr_tts.txt"
StayWithMe_VR.VoicesFile = "staywithme_vr_installed_voices.txt"
StayWithMe_VR.Visible = true
StayWithMe_VR._wantPalm = true
StayWithMe_VR._menuOpen = false
StayWithMe_VR._lastToggleMs = 0

local PANEL_W = 440
local PANEL_H = 240
local HEADER_H = 28
local PAD_X = 12
local LINE_H = 23
local MAX_DISPLAY_LINES = 8
local MAX_TEXT_W = PANEL_W - (PAD_X * 2)
local MAX_CHARS_FALLBACK = 46

local displayLines = {}
local lastLineText = ""
local lastLineTimeSec = 0
local lastPollMs = 0
local lastMetaCheckMs = 0
local cachedName = "Companion"
local cachedGender = "female"
local lastSayByChar = {}
local sayCount = 0
local lastChatRaw = ""
local lastChatPanelTail = ""
local palmChatPanel = nil

-----------------------------------------------------------------------
-- Safe Helpers
-----------------------------------------------------------------------
local function getNowMs()
    if type(getTimestampMs) == "function" then return getTimestampMs() end
    if type(getTimeInMillis) == "function" then return getTimeInMillis() end
    if type(getTimestamp) == "function" then return getTimestamp() * 1000 end
    return 0
end

local function getNowSec()
    if type(getTimestamp) == "function" then return getTimestamp() end
    return math.floor(getNowMs() / 1000)
end

local function asLuaTable(obj)
    if type(obj) == "table" then return obj end
    if type(obj) == "userdata" and type(obj.getTable) == "function" then
        local ok, tbl = pcall(function() return obj:getTable() end)
        if ok and type(tbl) == "table" then
            return tbl
        end
    end
    return nil
end

local function isVrActive()
    return VrApi and type(VrApi.status) == "function" and VrApi.status() == "VR_ACTIVE" and PZVRHandUI ~= nil
end

-----------------------------------------------------------------------
-- Vanilla Options -> Mods Menu (PZAPI.ModOptions) & Installed Voices
-----------------------------------------------------------------------
local DEFAULT_FEMALE_VOICES = {
    "Auto (Default Female)",
    "Microsoft Zira Desktop",
    "Microsoft Aria",
    "Microsoft Jenny",
    "Microsoft Eva Mobile",
    "Microsoft Hazel Desktop",
}

local DEFAULT_MALE_VOICES = {
    "Auto (Default Male)",
    "Microsoft David Desktop",
    "Microsoft Guy",
    "Microsoft Mark",
    "Microsoft George",
}

local GENDER_CHOICES = {
    "Auto (Match Companion)",
    "Female",
    "Male",
}

local function loadVoiceChoicesFromBridge()
    local femaleList = {}
    local maleList = {}
    local seenF = {}
    local seenM = {}

    local function pushUnique(list, seen, val)
        if type(val) ~= "string" then return end
        val = val:gsub("^%s+", ""):gsub("%s+$", "")
        if val ~= "" and not seen[val] then
            seen[val] = true
            table.insert(list, val)
        end
    end

    pushUnique(femaleList, seenF, "Auto (Default Female)")
    pushUnique(maleList, seenM, "Auto (Default Male)")

    if type(getFileReader) == "function" then
        pcall(function()
            local reader = getFileReader(StayWithMe_VR.VoicesFile, false)
            if reader then
                while true do
                    local line = reader:readLine()
                    if not line then break end
                    line = line:gsub("\r", "")
                    local g, vName = line:match("^([^|]+)|(.+)$")
                    if g and vName then
                        local gl = string.lower(g)
                        if gl == "male" then
                            pushUnique(maleList, seenM, vName)
                        elseif gl == "female" then
                            pushUnique(femaleList, seenF, vName)
                        else
                            pushUnique(femaleList, seenF, vName)
                            pushUnique(maleList, seenM, vName)
                        end
                    end
                end
                reader:close()
            end
        end)
    end

    for _, v in ipairs(DEFAULT_FEMALE_VOICES) do pushUnique(femaleList, seenF, v) end
    for _, v in ipairs(DEFAULT_MALE_VOICES) do pushUnique(maleList, seenM, v) end

    return femaleList, maleList
end

local swmModOptions = nil
local optCompanionName = nil
local optVoiceGender = nil
local optFemaleVoice = nil
local optMaleVoice = nil
local femaleVoiceChoices, maleVoiceChoices = loadVoiceChoicesFromBridge()

local function addSafeCombo(opts, id, label, items, defaultIdx, tooltip)
    local ok, res = pcall(function()
        return opts:addComboBox(id, label, tooltip)
    end)
    if ok and type(res) == "table" and type(res.addItem) == "function" then
        for idx, itemLabel in ipairs(items) do
            pcall(function() res:addItem(itemLabel, idx == (defaultIdx or 1)) end)
        end
        return res
    end

    local ok2, res2 = pcall(function()
        return opts:addComboBox(id, label, items, defaultIdx or 1, tooltip)
    end)
    if ok2 and type(res2) == "table" then
        return res2
    end
    return nil
end

local function initModOptions()
    if StayWithMe_VR._modOptionsInit then return end
    if not PZAPI or not PZAPI.ModOptions or type(PZAPI.ModOptions.create) ~= "function" then
        return
    end
    StayWithMe_VR._modOptionsInit = true

    pcall(function()
        swmModOptions = PZAPI.ModOptions:create("StayWithMe_PZVR", "Stay With Me - VR Chat & Voice")
        if not swmModOptions then return end

        if type(swmModOptions.addDescription) == "function" then
            pcall(function()
                swmModOptions:addDescription("Configure TTS voices and the Companion Name Failsafe (if set, TTS only reads lines formatted as '<Name>: message').")
            end)
        end

        if type(swmModOptions.addTextEntry) == "function" then
            local okTxt, resTxt = pcall(function()
                return swmModOptions:addTextEntry(
                    "companionName",
                    "Companion Name Failsafe (Reads ONLY '<Name>: ...')",
                    "",
                    "Failsafe filter: enter your companion's exact name. When set, TTS ONLY reads chat text that comes after '<Name>:'. Leave blank for auto-detection."
                )
            end)
            if okTxt then optCompanionName = resTxt end
        end

        if type(swmModOptions.addComboBox) == "function" then
            optVoiceGender = addSafeCombo(
                swmModOptions,
                "voiceGender",
                "Voice Gender",
                GENDER_CHOICES,
                1,
                "Auto detects your companion's gender from Stay With Me."
            )
            optFemaleVoice = addSafeCombo(
                swmModOptions,
                "femaleVoice",
                "Female TTS Voice",
                femaleVoiceChoices,
                1,
                "Select female TTS voice (restart voice reader once to refresh list)."
            )
            optMaleVoice = addSafeCombo(
                swmModOptions,
                "maleVoice",
                "Male TTS Voice",
                maleVoiceChoices,
                1,
                "Select male TTS voice (restart voice reader once to refresh list)."
            )
        end

        local prevApply = swmModOptions.apply
        swmModOptions.apply = function(self, ...)
            if type(prevApply) == "function" then
                pcall(prevApply, self, ...)
            end
            lastMetaCheckMs = 0
        end
    end)
end

local function readOptionRaw(optObj, id)
    if type(optObj) == "table" then
        if type(optObj.getValue) == "function" then
            local ok, v = pcall(function() return optObj:getValue() end)
            if ok and v ~= nil then return v end
        end
        if optObj.selected ~= nil then return optObj.selected end
        if optObj.value ~= nil then return optObj.value end
        if optObj.text ~= nil then return optObj.text end
    end
    local modOpts = swmModOptions
    if (not modOpts or type(modOpts.getOption) ~= "function") and PZAPI and PZAPI.ModOptions and type(PZAPI.ModOptions.getOptions) == "function" then
        local okM, foundM = pcall(function() return PZAPI.ModOptions:getOptions("StayWithMe_PZVR") end)
        if okM and type(foundM) == "table" then
            modOpts = foundM
        end
    end
    if modOpts and type(modOpts.getOption) == "function" then
        local ok, o = pcall(function() return modOpts:getOption(id) end)
        if ok and type(o) == "table" then
            if type(o.getValue) == "function" then
                local ok2, v = pcall(function() return o:getValue() end)
                if ok2 and v ~= nil then return v end
            end
            if o.selected ~= nil then return o.selected end
            if o.value ~= nil then return o.value end
            return o.text
        end
    end
    return nil
end

local function resolveComboString(optObj, id, choices)
    local raw = readOptionRaw(optObj, id)
    if type(raw) == "number" then
        return choices[raw] or choices[1]
    elseif type(raw) == "string" and raw ~= "" then
        return raw
    end
    return choices[1]
end

local function getModOptionNameOverride()
    local raw = readOptionRaw(optCompanionName, "companionName")
    if type(raw) == "string" then
        -- Trim whitespace and strip any trailing ':' in case user included a colon after the name
        local trimmed = raw:gsub("^%s+", ""):gsub("%s+$", ""):gsub(":+$", ""):gsub("%s+$", "")
        if trimmed ~= "" then
            return trimmed
        end
    end
    return nil
end

local function getConfiguredVoiceForGender(detectedGender)
    local gChoice = resolveComboString(optVoiceGender, "voiceGender", GENDER_CHOICES)
    local finalGender = detectedGender == "male" and "male" or "female"
    if gChoice == "Female" then
        finalGender = "female"
    elseif gChoice == "Male" then
        finalGender = "male"
    end

    local selectedVoice = finalGender == "male"
        and resolveComboString(optMaleVoice, "maleVoice", maleVoiceChoices)
        or resolveComboString(optFemaleVoice, "femaleVoice", femaleVoiceChoices)

    if type(selectedVoice) ~= "string" or string.sub(selectedVoice, 1, 4) == "Auto" then
        selectedVoice = ""
    end
    return finalGender, selectedVoice
end

initModOptions()

-----------------------------------------------------------------------
-- Safe Companion Discovery (BridgeChat, BridgeSocial, Save ModData)
-----------------------------------------------------------------------
local function readMetaFromChar(obj, allowNameOverwrite)
    if not obj then return end
    if allowNameOverwrite and type(obj.getDescriptor) == "function" then
        local ok, desc = pcall(function() return obj:getDescriptor() end)
        if ok and desc and type(desc.getForename) == "function" then
            local fname = desc:getForename()
            if type(fname) == "string" and fname ~= "" then
                cachedName = fname
            end
        end
    end
    if type(obj.isFemale) == "function" then
        local ok, fem = pcall(function() return obj:isFemale() end)
        if ok and fem ~= nil then
            cachedGender = fem and "female" or "male"
        end
    end
end

local function inspectCompanionTable(tbl, allowGenericName, allowNameOverwrite)
    if type(tbl) ~= "table" then return false end
    local foundName = (type(tbl.companionName) == "string" and tbl.companionName ~= "" and tbl.companionName)
        or (type(tbl.CompanionName) == "string" and tbl.CompanionName ~= "" and tbl.CompanionName)
        or (type(tbl.customName) == "string" and tbl.customName ~= "" and tbl.customName)
        or (type(tbl.rinName) == "string" and tbl.rinName ~= "" and tbl.rinName)
        or (allowGenericName and type(tbl.name) == "string" and tbl.name ~= "" and tbl.name)
        or (allowGenericName and type(tbl.Name) == "string" and tbl.Name ~= "" and tbl.Name)
        or nil

    local gotAuthoritative = false
    if foundName and (allowNameOverwrite or cachedName == "Companion") then
        cachedName = foundName
        gotAuthoritative = true
    end

    if tbl.isFemale ~= nil then
        cachedGender = tbl.isFemale and "female" or "male"
    elseif tbl.isMale ~= nil then
        cachedGender = tbl.isMale and "male" or "female"
    elseif type(tbl.gender) == "string" and tbl.gender ~= "" then
        cachedGender = string.lower(tbl.gender) == "male" and "male" or "female"
    elseif type(tbl.Gender) == "string" and tbl.Gender ~= "" then
        cachedGender = string.lower(tbl.Gender) == "male" and "male" or "female"
    end
    return gotAuthoritative
end

local function readCompanionMeta(forceRefresh)
    local nowMs = getNowMs()
    local overrideName = getModOptionNameOverride()
    if overrideName then
        cachedName = overrideName
    end

    if not forceRefresh and cachedName ~= "Companion" and lastMetaCheckMs > 0 and (nowMs - lastMetaCheckMs) < 2000 then
        local effectiveGender = getConfiguredVoiceForGender(cachedGender)
        return cachedName, effectiveGender, nil
    end
    lastMetaCheckMs = nowMs

    local hasAuthName = overrideName ~= nil

    -- 1. Direct Stay With Me save name
    if not hasAuthName and BridgeChat and type(BridgeChat.companionName) == "function" then
        local ok, cname = pcall(function() return BridgeChat.companionName() end)
        if ok and type(cname) == "string" and cname ~= "" then
            cachedName = cname
            hasAuthName = true
        end
    end

    local hasAuthGender = false
    if BridgeSocial and type(BridgeSocial.isMale) == "function" then
        local ok, male = pcall(function() return BridgeSocial.isMale() end)
        if ok and male ~= nil then
            cachedGender = male and "male" or "female"
            hasAuthGender = true
        end
    end

    -- 2. Check player ModData
    local player = getSpecificPlayer(0)
    local comp = nil
    if player and type(player.getModData) == "function" then
        local pData = player:getModData()
        if type(pData) == "table" then
            if BridgeData and type(BridgeData.KEY) == "string" and type(pData[BridgeData.KEY]) == "table" then
                if inspectCompanionTable(pData[BridgeData.KEY], true, not hasAuthName) then
                    hasAuthName = true
                end
            end
            for k, v in pairs(pData) do
                local kl = string.lower(tostring(k))
                if string.find(kl, "stay") or string.find(kl, "companion") or string.find(kl, "bridge") then
                    if type(v) == "table" and inspectCompanionTable(v, false, not hasAuthName) then
                        hasAuthName = true
                    end
                end
            end
        end
    end

    -- 3. Save global ModData tables (only if name or gender not resolved yet)
    if (not hasAuthName or not hasAuthGender) and ModData and type(ModData.getTableNames) == "function" and type(ModData.get) == "function" then
        local okList, tagNames = pcall(function() return ModData.getTableNames() end)
        if okList and tagNames and type(tagNames.size) == "function" then
            for i = 0, tagNames:size() - 1 do
                local tag = tostring(tagNames:get(i) or "")
                local tagLower = string.lower(tag)
                if string.find(tagLower, "bridge") or string.find(tagLower, "stay") or string.find(tagLower, "companion") then
                    local okTbl, tbl = pcall(function() return ModData.get(tag) end)
                    if okTbl and type(tbl) == "table" then
                        if inspectCompanionTable(tbl, false, not hasAuthName) then
                            hasAuthName = true
                        end
                    end
                end
            end
        end
    end

    -- 4. BridgeLooks gender/name fallback ONLY if still unresolved
    if (not hasAuthName or not hasAuthGender) and BridgeLooks and type(BridgeLooks.current) == "function" then
        local ok, cur = pcall(function() return BridgeLooks.current() end)
        if ok and cur then
            if type(cur) == "table" and not hasAuthName then
                if inspectCompanionTable(cur, true, true) then
                    hasAuthName = true
                end
            end
            if not hasAuthGender and type(BridgeLooks.genderOf) == "function" then
                local okG, g = pcall(function() return BridgeLooks.genderOf(cur) end)
                if okG and type(g) == "string" and g ~= "" then
                    cachedGender = string.lower(g) == "male" and "male" or "female"
                    hasAuthGender = true
                end
            end
        end
    end

    -- 5. Resolve live Stay With Me companion body (never overwrite custom name from descriptor)
    if BridgeCompanion and type(BridgeCompanion.bodies) == "function" then
        local okB, bodies = pcall(function() return BridgeCompanion.bodies() end)
        if okB and type(bodies) == "table" then
            for _, b in pairs(bodies) do
                if b then
                    comp = b
                    readMetaFromChar(b, not hasAuthName)
                    break
                end
            end
        end
    end

    local effectiveGender = getConfiguredVoiceForGender(cachedGender)
    return cachedName, effectiveGender, comp
end

-----------------------------------------------------------------------
-- Sandboxed TTS Queue Writer (gender|speaker|text|voiceHint)
-----------------------------------------------------------------------
local function appendTtsQueue(gender, speaker, text)
    local finalGender, voiceHint = getConfiguredVoiceForGender(gender)
    local safeSpeaker = tostring(speaker):gsub("|", " ")
    local safeText = tostring(text):gsub("|", " "):gsub("[\r\n]+", " ")
    local safeHint = tostring(voiceHint or ""):gsub("|", " ")
    local writer = getFileWriter(StayWithMe_VR.QueueFile, true, true)
    if writer then
        writer:write(string.format("%s|%s|%s|%s\n", finalGender, safeSpeaker, safeText, safeHint))
        writer:close()
    end
end

local function clearTtsQueue()
    local writer = getFileWriter(StayWithMe_VR.QueueFile, true, false)
    if writer then
        writer:write("")
        writer:close()
    end
end

-----------------------------------------------------------------------
-- Line Cleaning, Timestamp/Name Stripping, Deduplication & Pixel Wrap
-----------------------------------------------------------------------
local function cleanDialogueText(raw)
    if not raw then return "" end
    local s = tostring(raw)
    s = s:gsub("<[^>]+>", " ")
    s = s:gsub("%[col=[^%]]+%]", " ")
    s = s:gsub("%[/col%]", " ")
    s = s:gsub("%[img=[^%]]+%]", " ")
    s = s:gsub("[\r\n]+", " ")
    s = s:gsub("%s+", " ")
    s = s:gsub("^%s+", ""):gsub("%s+$", "")
    return s
end

local function stripLeadingMeta(raw)
    local s = cleanDialogueText(raw)
    if s == "" then return "" end

    for _ = 1, 8 do
        local prev = s
        s = s:gsub("^%[[^%]]*%]%s*", "")
        s = s:gsub("^%(%s*%d+:%d+[^%)]*%)%s*", "")
        s = s:gsub("^%d%d?:%d%d:%d%d%s*[APap]?[Mm]?%s*[-:|>]?%s*", "")
        s = s:gsub("^%d%d?:%d%d%s*[APap]?[Mm]?%s*[-:|>]?%s*", "")
        s = s:gsub("^[-:|>]%s*", "")
        s = s:gsub("^%s+", "")
        if s == prev or s == "" then break end
    end
    return s
end

local function stripSpeakerPrefixCI(text, speakerName)
    local s = stripLeadingMeta(text)
    if s == "" or type(speakerName) ~= "string" or speakerName == "" then
        return s
    end
    local targetLower = string.lower(speakerName)
    for _ = 1, 3 do
        local pName, pBody = s:match("^([^:%[%]]+)%s*:%s*(.+)$")
        if pName and pBody then
            local pTrim = cleanDialogueText(pName)
            if string.lower(pTrim) == targetLower then
                s = stripLeadingMeta(pBody)
            else
                break
            end
        else
            break
        end
    end
    return s
end

local function extractTailLine(rawText)
    if not rawText then return "" end
    local normalized = tostring(rawText)
    normalized = normalized:gsub("<[Ll][Ii][Nn][Ee]>", "\n")
    normalized = normalized:gsub("<[Bb][Rr]%s*/?>", "\n")
    local latest = ""
    for line in normalized:gmatch("[^\r\n]+") do
        local cleaned = cleanDialogueText(line)
        if cleaned ~= "" then
            latest = cleaned
        end
    end
    return latest
end

local function measureLineWidth(str)
    local tm = type(getTextManager) == "function" and getTextManager() or nil
    if tm and type(tm.MeasureStringX) == "function" then
        local ok, w = pcall(function() return tm:MeasureStringX(UIFont.Medium, str) end)
        if ok and type(w) == "number" then
            return w
        end
    end
    return #str * 9
end

local function fitsBoxWidth(str)
    if type(getTextManager) == "function" then
        return measureLineWidth(str) <= MAX_TEXT_W
    end
    return #str <= MAX_CHARS_FALLBACK
end

local function appendWrappedDisplayLine(speaker, text)
    local full = speaker .. ": " .. text
    local current = ""
    local linesForMsg = {}

    for word in full:gmatch("%S+") do
        if #current == 0 then
            current = word
        else
            local candidate = current .. " " .. word
            if fitsBoxWidth(candidate) then
                current = candidate
            else
                table.insert(linesForMsg, current)
                current = "  " .. word
            end
        end
    end

    if current ~= "" then
        table.insert(linesForMsg, current)
    end

    for _, lineStr in ipairs(linesForMsg) do
        table.insert(displayLines, { text = lineStr })
    end

    while #displayLines > MAX_DISPLAY_LINES do
        table.remove(displayLines, 1)
    end
end

local function pushCompanionLine(speaker, gender, text)
    local activeSpeaker = (type(speaker) == "string" and speaker ~= "" and speaker ~= "Companion") and speaker or cachedName
    local clean = stripSpeakerPrefixCI(text, activeSpeaker)
    if clean == "" then return end

    local normKey = string.lower(clean)
    local now = getNowSec()
    if normKey == lastLineText and (now - lastLineTimeSec) < 4 then
        return
    end
    lastLineText = normKey
    lastLineTimeSec = now

    appendWrappedDisplayLine(activeSpeaker, clean)
    appendTtsQueue(gender or cachedGender, activeSpeaker, clean)
end

-----------------------------------------------------------------------
-- Native PZVR Left-Hand Palm Panel (SWM_VR_PalmChat)
-----------------------------------------------------------------------
local SWMPalmChatPanel = ISPanel:derive("SWM_VR_PalmChat")

function SWMPalmChatPanel:new(x, y, width, height)
    local o = ISPanel:new(x, y, width, height)
    setmetatable(o, self)
    self.__index = self
    o.Type = "SWM_VR_PalmChat"
    o.pzvrPalm = true
    o.moveWithMouse = false
    o.background = false
    o.backgroundColor = { r = 0, g = 0, b = 0, a = 0 }
    o.borderColor = { r = 0, g = 0, b = 0, a = 0 }
    return o
end

local function drawPanelTextShadow(panel, textStr, x, y, r, g, b, a)
    panel:drawText(textStr, x + 1, y + 1, 0.0, 0.0, 0.0, 0.92, UIFont.Medium)
    panel:drawText(textStr, x, y, r, g, b, a or 1.0, UIFont.Medium)
end

function SWMPalmChatPanel:render()
    if not StayWithMe_VR.Visible then return end
    if type(isGamePaused) == "function" and isGamePaused() then return end

    self:drawRect(0, 0, self.width, self.height, 0.90, 0.05, 0.05, 0.07)
    self:drawRect(0, 0, self.width, HEADER_H, 0.96, 0.11, 0.12, 0.15)
    self:drawRectBorder(0, 0, self.width, self.height, 0.95, 0.56, 0.58, 0.64)
    self:drawRectBorder(0, 0, self.width, HEADER_H, 0.95, 0.56, 0.58, 0.64)

    local titleStr = "Stay With Me - " .. tostring(cachedName)
    drawPanelTextShadow(self, titleStr, PAD_X, 5, 0.98, 0.98, 0.98, 1.0)

    local lineY = HEADER_H + 10
    if #displayLines == 0 then
        local waitStr = "Listening for " .. tostring(cachedName) .. "..."
        drawPanelTextShadow(self, waitStr, PAD_X, lineY, 0.78, 0.82, 0.88, 1.0)
        return
    end

    for i = 1, #displayLines do
        drawPanelTextShadow(self, displayLines[i].text, PAD_X, lineY, 0.98, 0.98, 0.98, 1.0)
        lineY = lineY + LINE_H
    end
end

local function registerPalmPanel(panel)
    if not panel or not PZVRHandUI then return end
    PZVRHandUI.saved = PZVRHandUI.saved or {}
    if not PZVRHandUI.saved[panel] then
        PZVRHandUI.saved[panel] = {
            visible = false,
            x = panel:getX(),
            y = panel:getY(),
        }
    end
end

local function positionPanelForDesktop(panel)
    if not panel then return end
    local core = type(getCore) == "function" and getCore() or nil
    local sw = (core and type(core.getScreenWidth) == "function" and core:getScreenWidth()) or 1280
    local sh = (core and type(core.getScreenHeight) == "function" and core:getScreenHeight()) or 720
    panel:setX(math.floor((sw - PANEL_W) / 2))
    panel:setY(math.max(24, sh - PANEL_H - 96))
end

local function ensurePalmPanel()
    if palmChatPanel then
        if PZVRHandUI and PZVRHandUI.active then
            registerPalmPanel(palmChatPanel)
        end
        return palmChatPanel
    end

    local x, y = 24, 24
    local panel = SWMPalmChatPanel:new(x, y, PANEL_W, PANEL_H)
    panel:initialise()
    panel:instantiate()
    panel:addToUIManager()
    panel:setVisible(false)
    if type(panel.setWantKeyEvents) == "function" then
        pcall(function() panel:setWantKeyEvents(false) end)
    end
    palmChatPanel = panel
    registerPalmPanel(panel)
    return panel
end

-----------------------------------------------------------------------
-- Inventory / Viewpoint Screen Detection (Safe Userdata Unwrapping)
-----------------------------------------------------------------------
local BLOCKING_MENU_TYPES = {
    ischaracterinfowindow = true,
    ishealthpanel = true,
    isworldmap = true,
    isoptions = true,
    mainoptions = true,
    isescmenu = true,
    mainscreen = true,
    isvehiclemechanics = true,
    isentityui = true,
    ishandcraftwindow = true,
    isbuildwindow = true,
}

local function checkInventoryOrMenuOpen()
    if type(isGamePaused) == "function" and isGamePaused() then
        return true
    end

    if MainScreen and MainScreen.instance and type(MainScreen.instance.isVisible) == "function" then
        if MainScreen.instance:isVisible() then return true end
    end

    if ISEscMenu and ISEscMenu.instance and type(ISEscMenu.instance.isVisible) == "function" then
        if ISEscMenu.instance:isVisible() then return true end
    end

    if Viewpoint and Viewpoint.Inventory and type(Viewpoint.Inventory.up) == "function" then
        local okUp, isUp = pcall(function() return Viewpoint.Inventory.up() end)
        if okUp and isUp == true then return true end
    end

    local inv = type(getPlayerInventory) == "function" and getPlayerInventory(0) or nil
    if inv and type(inv.isVisible) == "function" and inv:isVisible() and inv.isCollapsed == false then
        return true
    end

    local loot = type(getPlayerLoot) == "function" and getPlayerLoot(0) or nil
    if loot and type(loot.isVisible) == "function" and loot:isVisible() and loot.isCollapsed == false then
        return true
    end

    local uiList = UIManager.getUI()
    if not uiList then return false end

    for i = 0, uiList:size() - 1 do
        local elem = uiList:get(i)
        if elem and type(elem.isVisible) == "function" and elem:isVisible() then
            local tbl = asLuaTable(elem)
            if tbl then
                local typeLower = type(tbl.Type) == "string" and string.lower(tbl.Type) or ""
                if typeLower == "isinventorypage" and tbl.isCollapsed == false then
                    return true
                end
                if BLOCKING_MENU_TYPES[typeLower] then
                    return true
                end
            end
        end
    end

    return false
end

local function activatePalmChat(panel)
    if not panel or not PZVRHandUI then return end
    panel:setX(24)
    panel:setY(24)
    registerPalmPanel(panel)
    PZVRHandUI.selected = "swmChatBtn"
    PZVRHandUI.selection = panel
    PZVRHandUI.childPage = nil
    PZVRHandUI.dismissed = false
    PZVRHandUI.showing = false
end

function StayWithMe_VR.ToggleWindow()
    local panel = ensurePalmPanel()
    StayWithMe_VR._menuOpen = checkInventoryOrMenuOpen()
    StayWithMe_VR._lastToggleMs = getNowMs()

    if isVrActive() then
        local currentlyOpen = StayWithMe_VR.Visible and StayWithMe_VR._wantPalm and (PZVRHandUI.selected == "swmChatBtn")
        if not currentlyOpen then
            StayWithMe_VR.Visible = true
            StayWithMe_VR._wantPalm = true
            activatePalmChat(panel)
        else
            StayWithMe_VR.Visible = false
            StayWithMe_VR._wantPalm = false
            if PZVRHandUI.selected == "swmChatBtn" then
                PZVRHandUI.selected = nil
            end
            if PZVRHandUI.selection == panel then
                PZVRHandUI.selection = nil
            end
            panel:setVisible(false)
            if type(VrApi.palmPage) == "function" then
                pcall(VrApi.palmPage, nil, 0, 0, 0, 0)
            end
        end
    else
        StayWithMe_VR.Visible = not StayWithMe_VR.Visible
        StayWithMe_VR._wantPalm = StayWithMe_VR.Visible
        positionPanelForDesktop(panel)
        panel:setVisible(StayWithMe_VR.Visible and not StayWithMe_VR._menuOpen)
    end
end

-----------------------------------------------------------------------
-- STRICT Companion-Only Chat Filter (Ignores All Non-Companion Lines)
-----------------------------------------------------------------------
local NON_COMPANION_PREFIXES = {
    server = true,
    system = true,
    admin = true,
    info = true,
    warn = true,
    warning = true,
    error = true,
    radio = true,
    tv = true,
    debug = true,
    log = true,
    tip = true,
    hint = true,
    notice = true,
    status = true,
    alert = true,
    whisper = true,
    yell = true,
    say = true,
    ["local"] = true,
    global = true,
    faction = true,
    safehouse = true,
    zombiebuddy = true,
    viewpoint = true,
    pzvr = true,
    staywithme = true,
    bridge = true,
}

local function getLocalPlayerNames()
    local player = getSpecificPlayer(0)
    if not player then return "", "" end
    local localUser = type(player.getUsername) == "function" and string.lower(tostring(player:getUsername() or "")) or ""
    local localDesc = type(player.getDescriptor) == "function" and player:getDescriptor() or nil
    local localFore = localDesc and type(localDesc.getForename) == "function" and string.lower(tostring(localDesc:getForename() or "")) or ""
    return localUser, localFore
end

local function handleChatPayload(authorRaw, textRaw)
    local stripped = stripLeadingMeta(textRaw)
    if stripped == "" then return end

    local failsafeName = getModOptionNameOverride()
    local compName, compGender = readCompanionMeta(false)
    local targetName = failsafeName or compName
    local localUser, localFore = getLocalPlayerNames()

    local parsedName, parsedBody = stripped:match("^([^:%[%]]+)%s*:%s*(.+)$")
    local author = ""
    local body = ""

    if parsedName and parsedBody then
        local pTrim = cleanDialogueText(parsedName)
        if #pTrim <= 28 and not pTrim:match("^%d+$") then
            author = pTrim
            body = stripLeadingMeta(parsedBody)
        end
    elseif not failsafeName then
        -- Only fall back to ChatMessage author when strict failsafe is NOT set
        author = cleanDialogueText(authorRaw)
        body = stripped
    end

    -- STRICT FAILSAFE: When a companion name is set in Options -> Mods,
    -- ONLY read text that explicitly comes after "<Name>:"!
    if author == "" or body == "" then
        return
    end

    local authorLower = string.lower(author)
    if authorLower == localUser or authorLower == localFore or NON_COMPANION_PREFIXES[authorLower] then
        return
    end

    if failsafeName then
        if authorLower ~= string.lower(failsafeName) then
            return
        end
    elseif targetName and targetName ~= "" and targetName ~= "Companion" then
        if authorLower ~= string.lower(targetName) then
            return
        end
    else
        -- Do NOT speak random chat lines if companion name has not resolved yet
        return
    end

    pushCompanionLine(author, compGender, body)
end

local function processChatMessageObject(message)
    if not message then return end
    if type(message) == "string" then
        handleChatPayload("", message)
        return
    end
    if type(message) == "table" then
        handleChatPayload(message.author or "", message.text or "")
        return
    end

    local author = type(message.getAuthor) == "function" and tostring(message:getAuthor() or "") or ""
    -- Prefer getTextWithPrefix() first so "<Name>: <body>" is preserved for strict matching
    local text = type(message.getTextWithPrefix) == "function" and tostring(message:getTextWithPrefix() or "") or ""
    if text == "" and type(message.getText) == "function" then
        text = tostring(message:getText() or "")
    end
    handleChatPayload(author, text)
end

local function pollSafe()
    local player = getSpecificPlayer(0)
    if not player then return end

    StayWithMe_VR._menuOpen = checkInventoryOrMenuOpen()
    local failsafeName = getModOptionNameOverride()
    local compName, compGender = readCompanionMeta(false)

    -- Keep palm panel registration & selection intact across VR state transitions or desktop fallback
    if palmChatPanel then
        if isVrActive() then
            if PZVRHandUI.active then
                registerPalmPanel(palmChatPanel)
                if StayWithMe_VR.Visible and StayWithMe_VR._wantPalm then
                    if PZVRHandUI.selected == nil or PZVRHandUI.selected == "swmChatBtn" then
                        PZVRHandUI.selected = "swmChatBtn"
                        PZVRHandUI.selection = palmChatPanel
                    end
                end
            end
        else
            palmChatPanel:setVisible(StayWithMe_VR.Visible and not StayWithMe_VR._menuOpen)
        end
    end

    -- A. Strict tail-line monitor on vanilla ISChat.instance.chatText (skip work if unchanged)
    if ISChat and ISChat.instance and ISChat.instance.chatText and type(ISChat.instance.chatText.text) == "string" then
        local raw = ISChat.instance.chatText.text
        if raw ~= "" and raw ~= lastChatRaw then
            lastChatRaw = raw
            local tail = extractTailLine(raw)
            if tail ~= "" and tail ~= lastChatPanelTail then
                lastChatPanelTail = tail
                handleChatPayload("", tail)
            end
        end
    end

    -- B. Speech bubble check ONLY when no strict name failsafe is active and companion name is known
    if not failsafeName and compName and compName ~= "" and compName ~= "Companion" then
        if BridgeCompanion and type(BridgeCompanion.bodies) == "function" then
            local okB, bodies = pcall(function() return BridgeCompanion.bodies() end)
            if okB and type(bodies) == "table" then
                for _, obj in pairs(bodies) do
                    if obj and type(obj.getSayLine) == "function" then
                        local sayLine = obj:getSayLine()
                        if sayLine and sayLine ~= "" and lastSayByChar[obj] ~= sayLine then
                            if sayCount > 8 then
                                lastSayByChar = {}
                                sayCount = 0
                            end
                            if not lastSayByChar[obj] then
                                sayCount = sayCount + 1
                            end
                            lastSayByChar[obj] = sayLine
                            local sName, sBody = stripLeadingMeta(sayLine):match("^([^:%[%]]+)%s*:%s*(.+)$")
                            if sName and sBody and string.lower(cleanDialogueText(sName)) == string.lower(compName) then
                                pushCompanionLine(compName, compGender, sBody)
                            end
                        end
                    end
                end
            end
        end
    end
end

-----------------------------------------------------------------------
-- PZVR Offhand Radial Identification
-----------------------------------------------------------------------
local function isOffhandPzvrRadial(self)
    if type(self) ~= "table" or type(self.slices) ~= "table" or #self.slices == 0 then
        return false
    end
    if self.pzvrPage ~= nil or type(self.pzvrLabels) == "table" or self.pzvrArmSwingAdded ~= nil then
        return true
    end
    return false
end

local function getRadialIcon()
    return getTexture("media/ui/SWM_VR_ChatIcon.png")
        or getTexture("media/ui/Moodles/Moodle_Icon_Happy.png")
        or getTexture("media/ui/ui_chat.png")
end

-----------------------------------------------------------------------
-- Hooks: BridgeChat, ISChat, PZVRHandUI Palm Page, Offhand Radial
-----------------------------------------------------------------------
local function installHooks()
    -- 1. Direct Stay With Me speech hook (skipped when strict failsafe requires explicit '<Name>: ...' chat lines)
    if BridgeChat and type(BridgeChat.sayCompanion) == "function" and not StayWithMe_VR._hookedBridgeSay then
        StayWithMe_VR._hookedBridgeSay = true
        local origSay = BridgeChat.sayCompanion
        BridgeChat.sayCompanion = function(...)
            local args = { ... }
            local r1, r2, r3 = origSay(...)
            pcall(function()
                if getModOptionNameOverride() then return end
                local compName, compGender = readCompanionMeta(false)
                if not compName or compName == "" or compName == "Companion" then return end
                local compLower = string.lower(compName)
                local spoken = ""
                for i = 1, #args do
                    if type(args[i]) == "string" and args[i] ~= "" then
                        local candidate = cleanDialogueText(args[i])
                        if string.lower(candidate) ~= compLower then
                            spoken = args[i]
                            break
                        end
                    end
                end
                if spoken ~= "" then
                    pushCompanionLine(compName, compGender, spoken)
                end
            end)
            return r1, r2, r3
        end
    end

    -- 2. Hook ISChat class AND live ISChat.instance
    if ISChat and type(ISChat.addLineInChat) == "function" and not StayWithMe_VR._hookedChatClass then
        StayWithMe_VR._hookedChatClass = true
        local origChat = ISChat.addLineInChat
        ISChat.addLineInChat = function(self, message, tabID, ...)
            origChat(self, message, tabID, ...)
            pcall(processChatMessageObject, message)
        end
    end

    if ISChat and ISChat.instance and type(ISChat.instance.addLineInChat) == "function"
        and ISChat.instance.addLineInChat ~= ISChat.addLineInChat and not ISChat.instance._swmHookedInst then
        ISChat.instance._swmHookedInst = true
        local origInstChat = ISChat.instance.addLineInChat
        ISChat.instance.addLineInChat = function(self, message, tabID, ...)
            origInstChat(self, message, tabID, ...)
            pcall(processChatMessageObject, message)
        end
    end

    -- 3. Hook PZVRHandUI palm lifecycle so our panel acts identically to Toggle Minimap
    if PZVRHandUI and type(PZVRHandUI.palmAvailable) == "function" and not StayWithMe_VR._hookedPalmAvailable then
        StayWithMe_VR._hookedPalmAvailable = true
        local origPalmAvailable = PZVRHandUI.palmAvailable
        PZVRHandUI.palmAvailable = function(key, ...)
            if key == "swmChatBtn" then
                return StayWithMe_VR.Visible and not StayWithMe_VR._menuOpen
            end
            return origPalmAvailable(key, ...)
        end
    end

    if PZVRHandUI and type(PZVRHandUI.palmSidebarTick) == "function" and not StayWithMe_VR._hookedSidebarTick then
        StayWithMe_VR._hookedSidebarTick = true
        local origSidebarTick = PZVRHandUI.palmSidebarTick
        PZVRHandUI.palmSidebarTick = function(active, ...)
            local wasChat = (PZVRHandUI.selected == "swmChatBtn")
            origSidebarTick(active, ...)
            if active and palmChatPanel then
                registerPalmPanel(palmChatPanel)
                local justToggled = (getNowMs() - (StayWithMe_VR._lastToggleMs or 0)) < 600
                if StayWithMe_VR.Visible and StayWithMe_VR._wantPalm then
                    if PZVRHandUI.selected == nil or wasChat or justToggled then
                        PZVRHandUI.selected = "swmChatBtn"
                        PZVRHandUI.selection = palmChatPanel
                    elseif PZVRHandUI.selected ~= "swmChatBtn" then
                        -- User explicitly picked another PZVR palm page (e.g. Minimap, Health, Crafting)
                        StayWithMe_VR.Visible = false
                        StayWithMe_VR._wantPalm = false
                        palmChatPanel:setVisible(false)
                    end
                end
            end
        end
    end

    -- 4. Inject speech-bubble toggle slice ONLY into PZVR offhand palm radial
    if ISRadialMenu and type(ISRadialMenu.addToUIManager) == "function" and not StayWithMe_VR._hookedRadial then
        StayWithMe_VR._hookedRadial = true

        local origClear = ISRadialMenu.clear
        if type(origClear) == "function" then
            ISRadialMenu.clear = function(self, ...)
                if type(self) == "table" then self._swmSliceAdded = false end
                return origClear(self, ...)
            end
        end

        local origAdd = ISRadialMenu.addToUIManager
        ISRadialMenu.addToUIManager = function(self, ...)
            pcall(function()
                if isOffhandPzvrRadial(self) and not self._swmSliceAdded then
                    self._swmSliceAdded = true
                    local isShowing = StayWithMe_VR.Visible
                        and (not PZVRHandUI or not isVrActive() or PZVRHandUI.selected == "swmChatBtn")
                    local label = isShowing and "Hide Companion Chat" or "Show Companion Chat"
                    self:addSlice(label, getRadialIcon(), function()
                        StayWithMe_VR.ToggleWindow()
                    end)
                end
            end)
            return origAdd(self, ...)
        end
    end
end

local function onAddMessage(message, tabId)
    pcall(processChatMessageObject, message)
end

local function cleanupPalmPanel()
    if palmChatPanel then
        local panel = palmChatPanel
        palmChatPanel = nil
        if PZVRHandUI then
            if PZVRHandUI.selected == "swmChatBtn" then PZVRHandUI.selected = nil end
            if PZVRHandUI.selection == panel then PZVRHandUI.selection = nil end
            if PZVRHandUI.saved then PZVRHandUI.saved[panel] = nil end
        end
        pcall(function()
            panel:setVisible(false)
            panel:removeFromUIManager()
        end)
    end
end

local function onGameStart()
    pcall(function()
        initModOptions()
        cleanupPalmPanel()
        displayLines = {}
        lastLineText = ""
        lastLineTimeSec = 0
        lastMetaCheckMs = 0
        -- Seed existing chat text on GameStart so pre-existing startup/welcome lines are ignored
        local existingRaw = (ISChat and ISChat.instance and ISChat.instance.chatText and type(ISChat.instance.chatText.text) == "string")
            and ISChat.instance.chatText.text or ""
        lastChatRaw = existingRaw
        lastChatPanelTail = existingRaw ~= "" and extractTailLine(existingRaw) or ""
        lastSayByChar = {}
        sayCount = 0
        StayWithMe_VR.Visible = true
        StayWithMe_VR._wantPalm = true
        StayWithMe_VR._menuOpen = false
        clearTtsQueue()
        readCompanionMeta(true)
        installHooks()
        local panel = ensurePalmPanel()
        if isVrActive() then
            activatePalmChat(panel)
        end
    end)
end

local function onMainMenuEnter()
    pcall(function()
        initModOptions()
        cleanupPalmPanel()
        displayLines = {}
        lastLineText = ""
        lastLineTimeSec = 0
        lastMetaCheckMs = 0
        lastChatRaw = ""
        lastChatPanelTail = ""
        lastSayByChar = {}
        sayCount = 0
        StayWithMe_VR.Visible = false
        StayWithMe_VR._wantPalm = false
        StayWithMe_VR._menuOpen = false
        clearTtsQueue()
    end)
end

local function onTick()
    pcall(function()
        local nowMs = getNowMs()
        if (nowMs - lastPollMs) < 350 then return end
        lastPollMs = nowMs
        installHooks()
        pollSafe()
    end)
end

local function onKeyPressed(key)
    pcall(function()
        if Keyboard and key == Keyboard.KEY_F9 then
            StayWithMe_VR.ToggleWindow()
        end
    end)
end

if Events.OnAddMessage then Events.OnAddMessage.Add(onAddMessage) end
if Events.OnGameStart then Events.OnGameStart.Add(onGameStart) end
if Events.OnMainMenuEnter then Events.OnMainMenuEnter.Add(onMainMenuEnter) end
if Events.OnTick then Events.OnTick.Add(onTick) end
if Events.OnKeyPressed then Events.OnKeyPressed.Add(onKeyPressed) end
