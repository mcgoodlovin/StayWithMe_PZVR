<#
  Stay With Me VR -> Free Windows Built-in + OneCore TTS Reader
  Author: mcgoodlovin
  Zero installs required. Discovers both Windows OneCore (e.g. Mark, Eva,
  Aria, Jenny, Guy if installed) and SAPI5 voices, exports them for Options -> Mods,
  and switches voices live.
#>

$LuaDir          = Join-Path $env:USERPROFILE "Zomboid\Lua"
$QueuePath       = Join-Path $LuaDir "staywithme_vr_tts.txt"
$VoicesPath      = Join-Path $LuaDir "staywithme_vr_installed_voices.txt"
$FemaleVoiceHint = "Microsoft Zira Desktop"
$MaleVoiceHint   = "Microsoft David Desktop"

if (-not (Test-Path $LuaDir)) { New-Item -ItemType Directory -Path $LuaDir -Force | Out-Null }

Add-Type -AssemblyName System.Speech
$sapiSynth = New-Object System.Speech.Synthesis.SpeechSynthesizer
$sapiVoices = @($sapiSynth.GetInstalledVoices() | Where-Object { $_.Enabled })

# Discover modern Windows 10/11 OneCore voices (WinRT) in addition to legacy SAPI5
$oneCoreAvailable = $false
$oneCoreSynth = $null
$oneCoreVoices = @()
$awaitStreamMethod = $null
try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $null = [Windows.Foundation.IAsyncOperation`1, Windows.Foundation, ContentType=WindowsRuntime]
    $null = [Windows.Media.SpeechSynthesis.SpeechSynthesizer, Windows.Media.SpeechSynthesis, ContentType=WindowsRuntime]
    $null = [Windows.Media.SpeechSynthesis.SpeechSynthesisStream, Windows.Media.SpeechSynthesis, ContentType=WindowsRuntime]
    $taskMethods = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 }
    $awaitStreamMethod = ($taskMethods | Where-Object { $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1).MakeGenericMethod([Windows.Media.SpeechSynthesis.SpeechSynthesisStream])
    $oneCoreSynth = New-Object Windows.Media.SpeechSynthesis.SpeechSynthesizer
    $oneCoreVoices = @([Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices)
    if ($oneCoreVoices.Count -gt 0 -and $awaitStreamMethod) {
        $oneCoreAvailable = $true
    }
} catch {
    $oneCoreAvailable = $false
}

$catalog = New-Object System.Collections.Generic.List[object]
if ($oneCoreAvailable) {
    foreach ($v in $oneCoreVoices) {
        $gStr = ([string]$v.Gender).ToLower()
        $catalog.Add([PSCustomObject]@{ Kind = "OneCore"; Name = [string]$v.DisplayName; Gender = $gStr; Ref = $v })
    }
}
foreach ($v in $sapiVoices) {
    $gStr = ([string]$v.VoiceInfo.Gender).ToLower()
    $catalog.Add([PSCustomObject]@{ Kind = "SAPI5"; Name = [string]$v.VoiceInfo.Name; Gender = $gStr; Ref = $v })
}

try {
    $voiceLines = New-Object System.Collections.Generic.List[string]
    $seenNames = @{}
    foreach ($entry in $catalog) {
        if ($entry.Name -ne "" -and -not $seenNames.ContainsKey($entry.Name)) {
            $seenNames[$entry.Name] = $true
            $voiceLines.Add(("{0}|{1}" -f $entry.Gender, $entry.Name))
        }
    }
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllLines($VoicesPath, $voiceLines, $utf8NoBom)
} catch {}

function Resolve-Voice([string]$hint, [string]$gender) {
    if ($hint -and $hint -ne "") {
        $exact = $catalog | Where-Object { $_.Name -eq $hint } | Select-Object -First 1
        if ($exact) { return $exact }
        $partial = $catalog | Where-Object { $_.Name -like "*$hint*" } | Select-Object -First 1
        if ($partial) { return $partial }
    }
    $oneCoreMatch = $catalog | Where-Object { $_.Kind -eq "OneCore" -and $_.Gender -ieq $gender } | Select-Object -First 1
    if ($oneCoreMatch) { return $oneCoreMatch }
    $fallback = $catalog | Where-Object { $_.Gender -ieq $gender } | Select-Object -First 1
    if ($fallback) { return $fallback }
    return ($catalog | Select-Object -First 1)
}

function Speak-WithEntry($entry, [string]$text) {
    if ($entry -and $entry.Kind -eq "OneCore" -and $oneCoreAvailable) {
        try {
            $oneCoreSynth.Voice = $entry.Ref
            $op = $oneCoreSynth.SynthesizeTextToStreamAsync($text)
            $netTask = $awaitStreamMethod.Invoke($null, @($op))
            $netTask.Wait(-1) | Out-Null
            $stream = $netTask.Result
            $netStream = $stream.AsStreamForRead()
            $player = New-Object System.Media.SoundPlayer $netStream
            $player.PlaySync()
            $player.Dispose()
            $netStream.Dispose()
            $stream.Dispose()
            return
        } catch {}
    }
    if ($entry) { try { $sapiSynth.SelectVoice($entry.Name) } catch {} }
    $sapiSynth.Speak($text)
}

$FemaleVoice = Resolve-Voice $FemaleVoiceHint "female"
$MaleVoice   = Resolve-Voice $MaleVoiceHint   "male"

Write-Host "[Stay With Me VR TTS] Installed voices exported to $VoicesPath"
Write-Host ("[Stay With Me VR TTS] Default Female voice: {0} ({1})" -f $FemaleVoice.Name, $FemaleVoice.Kind)
Write-Host ("[Stay With Me VR TTS] Default Male voice  : {0} ({1})" -f $MaleVoice.Name, $MaleVoice.Kind)
Write-Host "[Stay With Me VR TTS] Watching $QueuePath (Keep this window open while playing)"

try {
    $utf8Clear = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($QueuePath, "", $utf8Clear)
} catch {}

Speak-WithEntry $FemaleVoice "Stay With Me voice reader ready."

$lastCount = 0
while ($true) {
    if (Test-Path $QueuePath) {
        $lines = @(Get-Content -Path $QueuePath -Encoding UTF8 -ErrorAction SilentlyContinue)
        if ($lines.Count -lt $lastCount) { $lastCount = 0 }
        if ($lines.Count -gt $lastCount) {
            for ($i = $lastCount; $i -lt $lines.Count; $i++) {
                $raw = [string]$lines[$i]
                $parts = $raw.Trim() -split "\|", 4
                if ($parts.Count -ge 3 -and $parts[2] -ne "") {
                    $gender    = $parts[0]
                    $speaker   = $parts[1]
                    $text      = $parts[2]
                    $voiceHint = if ($parts.Count -ge 4) { $parts[3] } else { "" }
                    $chosen = if ($voiceHint -ne "") {
                        Resolve-Voice $voiceHint $gender
                    } elseif ($gender -eq "male") {
                        $MaleVoice
                    } else {
                        $FemaleVoice
                    }
                    Write-Host ("[{0} | {1}] {2}: {3}" -f $gender, $chosen.Name, $speaker, $text)
                    Speak-WithEntry $chosen $text
                }
            }
            $lastCount = $lines.Count
        }
    }
    Start-Sleep -Milliseconds 250
}
